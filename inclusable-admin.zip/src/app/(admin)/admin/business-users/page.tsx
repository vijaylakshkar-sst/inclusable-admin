// app/(admin)/term-conditions/page.tsx
'use client';

import BusinessUsersPage from '@/components/users/business-users/index';

export default function Page() {
  return <BusinessUsersPage />;
}
