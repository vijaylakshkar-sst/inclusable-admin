// app/(admin)/term-conditions/page.tsx
'use client';

import VehicleModelsPage from '@/components/masters/vehicleModels';

export default function Page() {
  return <VehicleModelsPage />;
}
