// app/(admin)/term-conditions/page.tsx
'use client';

import CancellationRules from "@/components/masters/cancellationRules";

export default function Page() {
  return <CancellationRules />;
}
