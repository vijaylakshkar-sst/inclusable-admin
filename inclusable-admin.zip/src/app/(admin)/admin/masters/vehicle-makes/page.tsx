// app/(admin)/term-conditions/page.tsx
'use client';

import VehicleMakesPage from '@/components/masters/vehicleMakes';

export default function Page() {
  return <VehicleMakesPage />;
}
