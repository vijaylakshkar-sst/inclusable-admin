// app/(admin)/term-conditions/page.tsx
'use client';

import CabTypePage from '@/components/masters/cabTypes/index';

export default function Page() {
  return <CabTypePage />;
}
