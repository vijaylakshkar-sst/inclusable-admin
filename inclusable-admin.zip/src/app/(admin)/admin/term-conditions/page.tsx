// app/(admin)/term-conditions/page.tsx
'use client';

import TermsListPage from '@/components/term-conditions/List';

export default function Page() {
  return <TermsListPage />;
}
