// app/(admin)/term-conditions/page.tsx
'use client';

import SupportTicketPage from '@/components/support-tickets/index';

export default function Page() {
  return <SupportTicketPage />;
}
