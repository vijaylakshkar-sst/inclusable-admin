// app/(admin)/term-conditions/page.tsx
'use client';

import NDISUsersPage from '@/components/users/ndis-users/index';

export default function Page() {
  return <NDISUsersPage />;
}
