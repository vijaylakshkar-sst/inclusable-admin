// app/(admin)/term-conditions/page.tsx
'use client';
import CabOwnersPage from '@/components/users/cab-owners';

export default function Page() {
  return <CabOwnersPage />;
}
