// app/(admin)/term-conditions/page.tsx
'use client';
import CabOwnerDetails from '@/components/users/cab-owners/details';
export default function Page() {
  return <CabOwnerDetails />;
}
