// app/(admin)/term-conditions/page.tsx
'use client';

import PrivacyPolicyPage from '@/components/privacy-policy/index';

export default function Page() {
  return <PrivacyPolicyPage />;
}
