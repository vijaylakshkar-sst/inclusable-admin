'use client'

import React, { useState, useEffect } from 'react'
import Input from '@/components/form/input/InputField'
import Label from '@/components/form/Label'
import Button from '@/components/ui/button/Button'
import { verifyOtpApi } from '@/api/auth/verifyOtp'
import { sendOtpApi } from '@/api/auth/sendOtp'
import { registerApi } from '@/api/auth/register'
import { useRouter } from 'next/navigation'

export default function VerifyOtpForm() {
  const router = useRouter()

  const [otp, setOtp] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [loading, setLoading] = useState(false)
  const [touched, setTouched] = useState(false)

  const [email, setEmail] = useState('')
  const [mobile, setMobile] = useState('')
  const [fullname, setFullname] = useState('')
  const [password, setPassword] = useState('')
  const [address, setAddress] = useState('') // ✅ Address state added

  const [timer, setTimer] = useState(30)
  const [isResendDisabled, setIsResendDisabled] = useState(true)

  useEffect(() => {
    const storedEmail = localStorage.getItem('register_email')
    const storedMobile = localStorage.getItem('register_mobile')
    const storedFullname = localStorage.getItem('register_fullname')
    const storedPassword = localStorage.getItem('register_password')
    const storedAddress = localStorage.getItem('register_address') // ✅ Get address

    if (!storedEmail || !storedMobile || !storedFullname || !storedPassword || !storedAddress) {
      router.push('/signup')
    } else {
      setEmail(storedEmail)
      setMobile(storedMobile)
      setFullname(storedFullname)
      setPassword(storedPassword)
      setAddress(storedAddress) // ✅ Set address
    }
  }, [])

  useEffect(() => {
  let countdown: NodeJS.Timeout | undefined

  if (isResendDisabled && timer > 0) {
    countdown = setInterval(() => {
      setTimer((prev) => prev - 1)
    }, 1000)
  } else {
    setIsResendDisabled(false)
  }

  return () => {
    if (countdown) clearInterval(countdown)
  }
}, [isResendDisabled, timer])

  const validateOtp = () => {
    if (!otp || otp.length !== 4) return 'OTP must be 4 digits'
    return ''
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setTouched(true)

    const otpError = validateOtp()
    if (otpError) {
      setError(otpError)
      return
    }

    setLoading(true)
    try {
      const verifyRes = await verifyOtpApi({ email, otp })
      if (!verifyRes.status) {
        setError(verifyRes.message || 'OTP verification failed')
        setLoading(false)
        return
      }

      // setSuccess('OTP verified successfully! Completing registration...')
      setError('')

      const registerRes = await registerApi({
        fullname,
        email,
        mobile,
        address, // ✅ Include address in register API call
        password,
      })

      if (registerRes.status) {
        // Clear localStorage
        localStorage.removeItem('register_fullname')
        localStorage.removeItem('register_email')
        localStorage.removeItem('register_mobile')
        localStorage.removeItem('register_password')
        localStorage.removeItem('register_address') // ✅ Clear address

        router.push('/complete?success=1')
      } else {
        setError(registerRes.message || 'Registration failed')
      }
    } catch (err: any) {
      setError(err.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  const handleResendOtp = async () => {
    setLoading(true)
    setError('')
    setSuccess('')

    try {
      const res = await sendOtpApi({ email, mobile, type: 'register' })
      if (res.status) {
        setSuccess('OTP resent successfully')
        setTimer(30)
        setIsResendDisabled(true)
      } else {
        setError(res.message || 'Failed to resend OTP')
      }
    } catch (err: any) {
      setError(err.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  const otpError = touched && validateOtp()

  return (
    <div className="flex flex-col flex-1 lg:w-1/2 w-full overflow-y-auto no-scrollbar">
      <div className="w-full max-w-md sm:pt-10 mx-auto mb-5" />

      <div className="flex flex-col justify-center flex-1 w-full max-w-md mx-auto">
        <div>
          <div className="mb-5 sm:mb-8">
            <h1 className="mb-2 font-semibold text-gray-800 text-title-sm dark:text-white/90 sm:text-title-md">
              Verify OTP
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Enter the 4-digit code sent to your email
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <Label>
                OTP<span className="text-error-500">*</span>
              </Label>
              <Input
                type="text"
                value={otp}
                onChange={(e) => {
                  setOtp(e.target.value)
                  setTouched(true)
                }}
                maxLength={4}
                className={`${
                  otpError
                    ? 'border-red-500'
                    : touched && !otpError
                    ? 'border-green-500'
                    : ''
                }`}
              />
              {otpError && (
                <p className="text-sm text-red-500 mt-1">{otpError}</p>
              )}
            </div>

            {error && <p className="text-sm text-red-600 mb-2">{error}</p>}
            {success && <p className="text-sm text-green-600 mb-2">{success}</p>}

            <Button type="submit" disabled={loading} className="w-full mb-3">
              {loading ? 'Verifying & Registering...' : 'Verify OTP'}
            </Button>

            <div className="text-sm text-center">
              {isResendDisabled ? (
                <p className="text-gray-500">
                  Resend available in <strong>{timer}s</strong>
                </p>
              ) : (
                <button
                  type="button"
                  onClick={handleResendOtp}
                  className="text-brand-500 hover:underline"
                >
                  Resend OTP
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
